//Richard Howell
//SNHU
//CS-320
// 2/6/2023

package TaskService;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class TaskService {
	
	// initiate task list array
	private final List<Task> taskList = new ArrayList<>();
	private String newUniqueId() {
	 return UUID.randomUUID().toString().substring(0, Math.min(toString().length(), 10));
	 }
	 
	private Task searchForTask(String id) throws Exception {
		int index = 0;
		while (index < taskList.size()) {
			if (id.equals(taskList.get(index).getTaskId())) {
				return taskList.get(index);
				}
	 
			index++;
			}
		throw new Exception("Task does not exist.");
		}
	
	// adding tasks names id descriptions and delete methods
	public void newTask() {
		Task task = new Task(newUniqueId());
		taskList.add(task);
		System.out.println("Unique ID was added succesfully!");
		}
	
	public void newTask(String name) {
		Task task = new Task(newUniqueId(), name);
		taskList.add(task);
		System.out.println("Name was added succesfully!");
		}
	 
	public void newTask(String name, String description) {
		Task task = new Task(newUniqueId(), name, description);
		taskList.add(task);
		System.out.println("Description was added succesfully!");
		}
	 
	public void deleteTask(String id) throws Exception {
		taskList.remove(searchForTask(id));
		System.out.println("Task was removed succesfully!");
		}
	 
	public void updateName(String id, String name) throws Exception {
		searchForTask(id).setName(name);
		System.out.println("Name was updated succesfully!");
		}
	 
	public void updateDescription(String id, String description)throws Exception {
		searchForTask(id).setDescription(description);
		System.out.println("Description was updated succesfully!");
		}

	public List<Task> getTaskList() {
		
		return taskList;
		}
	}
