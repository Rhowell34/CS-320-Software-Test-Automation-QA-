//Richard Howell
//SNHU
//CS-320
// 2/6/2023

package TaskService;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;


class TaskTest {
	
	// string set up naming Id name etc.
	private String id, name, description;
	private String idTooLong, nameTooLong, descriptionTooLong;
	 
	// set up for each test too long ID name description etc.
	@BeforeEach
	void setUp() {
		id = "0987654321";
		name = "Name <= 20 character";
		description = "This is a decription.";
		idTooLong = "111111111222222222333333333";
		nameTooLong = "This is way to long for the required task name.";
		descriptionTooLong = "The description needs to be longer than 50 characters to properly test "
				+ "this feild.";
		}
	
	// get task ID test 
	@Test
	void getTaskIdTest() {
		Task task = new Task(id);
		Assertions.assertEquals(id, task.getTaskId());
		}
	
	// get name test 
	@Test
	void getNameTest() {
		Task task = new Task(id, name);
		Assertions.assertEquals(name, task.getName());
		}
	
	// get description test 
	@Test
	void getDescriptionTest() {
		Task task = new Task(id, name, description);
		Assertions.assertEquals(description, task.getDescription());
		}
	
	// set name test 
	@Test
	void setNameTest() {
		Task task = new Task();
		task.setName(name);
		Assertions.assertEquals(name, task.getName());
		}
	// set description test  
	@Test
	void setDescriptionTest() {
		Task task = new Task();
		task.setDescription(description);
		Assertions.assertEquals(description, task.getDescription());
		}
	
	// task ID too long test throw exception 
	@Test
	void TaskIdTooLongTest() {
		Assertions.assertThrows(IllegalArgumentException.class,() -> new Task(idTooLong));
		}
	 
	// name too long test throw exception
	@Test
	void setnameTooLongTest() {
		Task task = new Task();
		Assertions.assertThrows(IllegalArgumentException.class,() -> task.setName(nameTooLong));
		}
	
	// set description to long test throw exception 
	@Test
	void setdescriptionTooLongTest() {
		Task task = new Task();
		Assertions.assertThrows(IllegalArgumentException.class,() -> task.setDescription(descriptionTooLong));
		}
	
	// Task Id cannot be null test throw exception 
	@Test
	void TaskIdNullTest() {
		Assertions.assertThrows(IllegalArgumentException.class,() -> new Task(null));
		}
	
	// Task Name cannot be null test throw exception
	@Test
	void TaskNameNullTest() {
		Task task = new Task();
		Assertions.assertThrows(IllegalArgumentException.class,() -> task.setName(null));
		}
	 
	// task description cannot be null test throw exception
	@Test
	void TaskDescriptionNullTest() {
		Task task = new Task();
		Assertions.assertThrows(IllegalArgumentException.class,() -> task.setDescription(null));
		}
	}

