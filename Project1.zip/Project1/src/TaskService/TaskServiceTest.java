//Richard Howell
//SNHU
//CS-320
// 2/6/2023

package TaskService;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.RepeatedTest;
import org.junit.jupiter.api.Test;

class TaskServiceTest {
	
	//string set up naming id name etc. 
	private String id, name, description;
	private String nameTooLong, descriptionTooLong;
	
	// set up for each test too long ID name description etc.
	@BeforeEach
	void setUp() {
		id = "0987654321";
		name = "Name <= 20 character";
		description = "This is a decription.";
		nameTooLong = "This is way to long for the required task name.";
		descriptionTooLong = "The description needs to be longer than 50 characters to properly test "
				+ "this feild.";
		}
	
	// new task test
	@Test
	void newTaskTest() {
		TaskService service = new TaskService();
		service.newTask();
		Assertions.assertNotNull(service.getTaskList().get(0).getTaskId());
		Assertions.assertNotEquals("INITIAL",service.getTaskList().get(0).getTaskId());
		}
	
	// new task name test
	@Test
	void newTaskNameTest() {
		TaskService service = new TaskService();
		service.newTask(name);
		Assertions.assertNotNull(service.getTaskList().get(0).getName());
		Assertions.assertEquals(name, service.getTaskList().get(0).getName());
		}
	
	// new task description test
	@Test
	 void newTaskDescriptionTest() {
		TaskService service = new TaskService();
		service.newTask(name, description);
		Assertions.assertNotNull(service.getTaskList().get(0).getDescription());
		Assertions.assertEquals(description,service.getTaskList().get(0).getDescription());
	}

	// new task name to long test throw exception 
	@Test
	void newTasknameTooLongTest() {
		TaskService service = new TaskService();
		Assertions.assertThrows(IllegalArgumentException.class,() -> service.newTask(nameTooLong));
		}
	
	// new task description to long throw exception
	@Test
	void newTaskdescriptionTooLongTest() {
		TaskService service = new TaskService();
		assertThrows(IllegalArgumentException.class,() -> service.newTask(name, descriptionTooLong));
		}
	
	// new task name null test if null throw exception  
	@Test
	void newTaskNameNullTest() {
		TaskService service = new TaskService();
		assertThrows(IllegalArgumentException.class,() -> service.newTask(null));
		}
	
	// new task description null test if null throw exception  
	@Test
	void newTaskDescriptionNullTest() {
		TaskService service = new TaskService();
		assertThrows(IllegalArgumentException.class,() -> service.newTask(name, null));
		}
	
	// task deletion test  
	@Test
	void deleteTaskTest() throws Exception {
		TaskService service = new TaskService();
		service.newTask();
		assertEquals(1, service.getTaskList().size());
		service.deleteTask(service.getTaskList().get(0).getTaskId());
		assertEquals(0, service.getTaskList().size());
		}
	
	// delete task not found test throw exception
	@Test
	void deleteTaskNotFoundTest() throws Exception {
		TaskService service = new TaskService();
		service.newTask();
		assertEquals(1, service.getTaskList().size());
		assertThrows(Exception.class, () -> service.deleteTask(id));
		assertEquals(1, service.getTaskList().size());
		}
	
	// update name test 
	@Test
	void updateNameTest() throws Exception {
		TaskService service = new TaskService();
		service.newTask();
		service.updateName(service.getTaskList().get(0).getTaskId(), name);
		assertEquals(name, service.getTaskList().get(0).getName());
		}
	
	// update name not found test   
	@Test
	void updateNameNotFoundTest() throws Exception {
		TaskService service = new TaskService();
		service.newTask();
		assertThrows(Exception.class, () -> service.updateName(id, name));
		}
	
	// update description not found test 
	@Test
	void updateDescriptionNotFoundTest() throws Exception {
		TaskService service = new TaskService();
		service.newTask();
		  assertThrows(Exception.class,() -> service.updateDescription(id, description));
	}
	
	// update description test 
	@Test
	void updateDescriptionTest() throws Exception {
		TaskService service = new TaskService();
		service.newTask();
		service.updateDescription(service.getTaskList().get(0).getTaskId(),description);
		assertEquals(description, service.getTaskList().get(0).getDescription());
	 }
	
	// repeat new task test
	@RepeatedTest(4)
	void UuidTest() {
		TaskService service = new TaskService();
		service.newTask();
		service.newTask();
		service.newTask();
		assertEquals(3, service.getTaskList().size());
		assertNotEquals(service.getTaskList().get(0).getTaskId(),service.getTaskList().get(1).getTaskId());
		assertNotEquals(service.getTaskList().get(0).getTaskId(),service.getTaskList().get(2).getTaskId());
		assertNotEquals(service.getTaskList().get(1).getTaskId(),service.getTaskList().get(2).getTaskId());
		}
	}


