//Richard Howell
//SNHU
//CS-320
// 2/6/2023

package TaskService;

public class Task  {
	private String taskId;
	private String name;
	private String description;
	
	public Task() {
		taskId = "Initial";
		name = "Initial";
		description = "Initial";
		}
	
	public Task(String taskId) {
		checkTaskId(taskId);
		name = "Initial";
		description = "Initial";
		}
	 
	public Task(String taskId, String name) {
		checkTaskId(taskId);
		setName(name);
		description = "Initial";
		}
	 
	public Task(String taskId, String name, String desc) {
		checkTaskId(taskId);
		setName(name);
		setDescription(desc);
		}
	 
	public final String getTaskId() {
		return taskId;
		}
	 
	public final String getName() {
		return name;
		}
	// name length set  
	public void setName(String name) {
		if (name == null || name.length() > 20) {
			throw new IllegalArgumentException("Task name is not valid, length to long.");
			}

		else {
			this.name = name;
			}
		}
	public final String getDescription() {
		return description; 
		}
	// task description length set  
	public void setDescription(String taskDescription) {
		if (taskDescription == null || taskDescription.length() > 50) {
			throw new IllegalArgumentException("Task description is not valid, length to long");
			}

		else {
			this.description = taskDescription;
			}
		}
	// task id length set
	private void checkTaskId(String taskId) {
		if (taskId == null || taskId.length() > 10) {
			throw new IllegalArgumentException("Task ID is not valid, length to long");
			}
		
		else {
			this.taskId = taskId;
			}
		}
	}


