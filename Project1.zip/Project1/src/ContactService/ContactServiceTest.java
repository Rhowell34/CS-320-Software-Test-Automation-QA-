//Richard Howell
//SNHU
//CS-320
// 2/6/2023


package ContactService;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;



class ContactServiceTest {
	//test for add
	@Test
	 public void testAdd(){
		ContactService cs = new ContactService();
		Contact t1 = new Contact("T1", "John", "Masters", "1234567890", "123 Hathersage Dr 123456");
		assertEquals(true, cs.addContact(t1));
	 }
	// test for delete 
	@Test
	 public void testDelete(){
		ContactService cs = new ContactService();
		Contact t1 = new Contact("T1", "John", "Masters", "1234567890", "123 Hathersage Dr 123456");
		Contact t2 = new Contact("T2", "James", "Thorton", "1234567890", "123 Hathersage Dr 1234567");
		Contact t3 = new Contact("T3", "Kim", "BoSlice", "1234567890", "123 Hathersage Dr 12345678");
	 
		cs.addContact(t1);
		cs.addContact(t2);
		cs.addContact(t3);
	 
		assertEquals(false, cs.deleteContact("T002"));
		assertEquals(false, cs.deleteContact("T000"));
		assertEquals(false, cs.deleteContact("T002"));
	 }
	// test for update
	 @Test
	 public void testUpdate(){
		 ContactService cs = new ContactService();
		 Contact t1 = new Contact("T1", "John", "Masters", "1234567890", "123 Hathersage Dr 123456");
		 Contact t2 = new Contact("T2", "James", "Thorton", "1234567890", "123 Hathersage Dr 123456");
		 Contact t3 = new Contact("T3", "Kim", "BoSlice", "1234567890", "123 Hathersage Dr 123456");
		 cs.addContact(t1);
		 cs.addContact(t2);
		 cs.addContact(t3);
		 assertEquals(true, cs.updateContact("T1", "John", "Masters", "1234567890", "123 Hathersage Dr 123456"));
		 assertEquals(true, cs.updateContact("T2", "James", "Thorton", "1234567890", "123 Hathersage Dr 123456"));
		 assertEquals(true, cs.updateContact("T3", "Kim", "BoSlice", "1234567890", "123 Hathersage Dr 123456"));
	 }
}