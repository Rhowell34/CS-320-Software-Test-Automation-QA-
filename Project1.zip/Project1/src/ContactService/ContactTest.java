//Richard Howell
//SNHU
//CS-320
// 2/6/2023


package ContactService;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;



class ContactTest {

	 Contact contact = new Contact("123456789", "firstName", "lastName", "1234567890", "123 Hathersage Dr 123456");
			  @Test
			  void getContactID() {
				  assertEquals("123456789", contact.getContactID());
			  }
			  @Test
			  void getFirstName() {
				  assertEquals("firstName", contact.getFirstName());
			  }
			  @Test
			  void getLastName() {
				  assertEquals("lastName", contact.getLastName());
			  }
			  @Test
			  void getNumber() {
				  assertEquals("1234567890", contact.getNumber());
			  }
			  @Test
			  void getAddress() {
				  assertEquals("123 Hathersage Dr 123456", contact.getAddress());
			  }
			  @Test
			  void testToString() {
				  assertEquals("Contact [contactID = 123456789, firstName = firstName, lastName = lastName, Number = 1234567890, address = 123 Hathersage Dr 123456]",contact.toString());
			  }
			// test to throw error for contact Id that is to long  
			  @Test 
			  void contactIdtoLong () {
				  Assertions.assertThrows(IllegalArgumentException.class,()-> {
					 Contact contact = new Contact("12345678901", "firstName", "lastName", "1234567890", "123 Hathersage Dr 123456");
				  });
				  }
			// test to throw error for first name that is to long 
			  @Test 
			  void contactFirstNametoLong () {
				  Assertions.assertThrows(IllegalArgumentException.class,()-> {
					 Contact contact = new Contact("123456789", "FirstName1111", "lastName", "1234567890", "123 Hathersage Dr 123456");
				  });
			  }
			// test to throw error for last name that is to long 
			  @Test 
			  void lastNametoLong () {
				  Assertions.assertThrows(IllegalArgumentException.class,()-> {
					 Contact contact = new Contact("123456789", "firstName", "lastName11111", "1234567890", "123 Hathersage Dr 123456");
				  });  
			  }
			  // test to throw error for phone number that is to long 
			  @Test 
			  void numberMoreThan10characters () {
				  Assertions.assertThrows(IllegalArgumentException.class,()-> {
					 Contact contact = new Contact("123456789", "firstName", "lastName", "123456789011", "123 Hathersage Dr 123456");
				  });
			  }
			// test to throw error for address that is to long 
			  @Test 
			  void addressToLong () {
				  Assertions.assertThrows(IllegalArgumentException.class,()-> {
					 Contact contact = new Contact("123456789", "firstName", "lastName", "1234567890", "123 Hathersage Dr 1234560000000");
				  });
			  }
			// test to throw error for phone number that is to short 
			  @Test 
			  void numberLessThan10Characters () {
				  Assertions.assertThrows(IllegalArgumentException.class,()-> {
					 Contact contact = new Contact("123456789", "firstName", "lastName", "123456789", "123 Hathersage Dr 123456");
				  });
			  }
			  // Test could be repeated for each string but this is not needed
			  @Test
			  void NullTest () {
				  Assertions.assertThrows(IllegalArgumentException.class,()-> {
					 Contact contact = new Contact("123456789", "lastName", "123456789", null , "123 Hathersage Dr 123456");
				  });
			  }
}  
