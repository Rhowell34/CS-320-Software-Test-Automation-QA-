//Richard Howell
//SNHU
//CS-320
// 2/6/2023

package ContactService;

public class Contact {
	private String contactID;
	private String firstName;
	private String lastName;
	private String number;
	private String address;
	 
	 public Contact(String contactID, String firstName, String lastName, String number, String address) {
		 // contact id is null or longer than 10 error 
		 if(contactID == null || contactID.length() > 10) {
			 throw new IllegalArgumentException("Contact ID is invalid, Null or length greater than 10");
	 }
		 // first name is null or longer than 10 error
		 if(firstName == null || firstName.length() > 10) {
			 throw new IllegalArgumentException("First Name is invalid, Null or length greater than 10");
	 }
		 // last name is null or longer than 10 error
		 if(lastName == null || lastName.length() > 10) {
			 throw new IllegalArgumentException("Last Name is invalid, Null or length greater than 10");
	 }
		 // phone number is null or not exactly 10 error
		 if(number == null || number.length() != 10) {
			 throw new IllegalArgumentException("Phone Number is invalid, Null or length more or less than 10");
	 }
		 // address is null or longer than 10 error
		 if(address == null || address.length() > 30) {
			 throw new IllegalArgumentException("Address is invalid, Null or length greater than 10");
	 }
		 
	 this.contactID = contactID;
	 this.firstName = firstName;
	 this.lastName = lastName;
	 this.number = number;
	 this.address = address;
	 }
	 
	 // getters for contact service class
	 public String getContactID() {
		 return this.contactID;
	 }
	 public String getFirstName() {
		 return this.firstName;
	 }
	 public String getLastName() {
		 return this.lastName;
	 }
	 public String getNumber() {
		 return this.number;
	 }
	 public String getAddress() {
		 return this.address;
		 }
	 // setters contact service class
	 public void setContactID(String contactId) {
		 this.contactID = contactID;
		 }
	 public void setFirstName(String fName) {
		 this.firstName = firstName;
		 }
	 public void setLastName(String lName) {
		 this.lastName = lastName;
		 }
	 public void setNumber(String num) {
		 this.number = number;
		 }
	 public void setAddress(String addr) {
		 this.address = address;
		 }
		 @Override
		 public String toString() {
		 return "Contact [" +
		 "contactID = " + contactID +
		 ", firstName = " + firstName +
		 ", lastName = " + lastName +
		 ", Number = " + number +
		 ", address = " + address +
		 ']';
		 }
}

