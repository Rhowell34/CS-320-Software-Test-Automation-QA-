//Richard Howell
//SNHU
//CS-320
// 2/6/2023

package AppointmentService;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;


class AppointmentServiceTest {

	//Testing to see if exception argument works properly
	@Test
	public void AppointmentServiceAddTestException() {
		AppointmentService appointment = new AppointmentService();
		appointment.add("1234567890");
		assertThrows(IllegalArgumentException.class,() -> {
			appointment.add("1234567890");
			});
		}
 
	//Test to verify add function is working
	@Test
	public void ContactServiceAddTest() {
		AppointmentService appointment = new AppointmentService();
		appointment.add("123456789");
		boolean isthere = false;
		// Parse through the array list looking for a match
		for ( int i = 0; i < appointment.getAppointmentService().size(); i++) {
			if
			(appointment.getAppointmentService().get(i).getID().equals("123456789")) {
				isthere = true;
				}
			assertTrue(isthere == true);
			}
	}

 //Test of the delete function
	@Test
	public void appointmentServiceDeleteTest() {
		AppointmentService appointment = new AppointmentService();
		appointment.add("123456789");
		appointment.add("098765432");
		appointment.delete("098765432");
		boolean isgone = true;
		
		//after method is called check to see if the item is removed from the list
		for ( int i = 0; i < appointment.getAppointmentService().size(); i++) {
			if
			(appointment.getAppointmentService().get(i).getID().equals("09875432")) {
				isgone = false;
				}
			assertTrue(isgone == true);
			}
	}
}

	
