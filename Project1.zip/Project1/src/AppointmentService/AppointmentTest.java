//Richard Howell
//SNHU
//CS-320
// 2/6/2023

package AppointmentService;

import java.util.Date;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;


class AppointmentTest {
	Date currentDate = new Date();
	
	 // Test using the setters and getters of the appointment class 1
	@Test
	public void testTaskClass(){
		Date currentDate = new Date();
		Appointment appointment = new Appointment("123456789",currentDate,"test Discription");
		assertTrue(appointment.getDate().equals(currentDate));
		assertTrue(appointment.getDescription().equals("test Discription"));
		assertTrue(appointment.getID().equals("123456789"));
		}
	
	//Test where all the fields are invalid
	@Test
	public void testApointmentClassTooLong() {
		Date oldDate = new Date(05,05,2021);
		assertThrows(IllegalArgumentException.class,() -> {new Appointment("1234567890111",oldDate ,"This discription will be enitirely to long please send help someone!!!!!!"); 
		});
		}
	
	//Test where ID field is too long
	@Test
	public void testAppointmentIDTooLong() {
		Date tempDate = new Date();
		assertThrows(IllegalArgumentException.class,()->{new Appointment("1234567890111",tempDate,"Test Discription");
		});
		}
	
	 //Test where Date is old
	 @Test
	 public void testDateAge() {
		 Date oldDate = new Date(05,05,2021);
		 assertThrows(IllegalArgumentException.class,()->{
			 new Appointment("123456789",oldDate,"test description");
			 });
		 }

	 //Test where Description is too long
	 @Test
	 public void descriptionLengthTest() {
		 Date tempDate = new Date();
		 assertThrows(IllegalArgumentException.class,()->{
			 new Appointment("123456789",tempDate,"This discription will be enitirely to long please send help someone!!!!!!");
			 });
		 }
	 
	 //Next Tests check for null throws
	 @Test
	 public void idNullCheck() {
		 Date tempDate = new Date();
		 assertThrows(IllegalArgumentException.class,()->{
			 new Appointment(null,tempDate,"test decription");
			 });
		 }
	 
	 @Test
	 public void DescriptionNullCheck() {
		 Date tempDate = new Date();
		 assertThrows(IllegalArgumentException.class,()->{
			 new Appointment("123456789",tempDate, null);
			 });
		 }
	 
	 @Test
	 public void nullDateCheck() {
		 assertThrows(IllegalArgumentException.class,()->{
			 new Appointment("123456789",null,"Test Discription");
			 });
		 }
	 }
