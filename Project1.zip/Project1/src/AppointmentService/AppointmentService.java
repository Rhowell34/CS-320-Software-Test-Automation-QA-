//Richard Howell
//SNHU
//CS-320
// 2/6/2023

package AppointmentService;

import java.util.ArrayList;


public class AppointmentService {
	private ArrayList<Appointment> appointment = new ArrayList<Appointment>();
	// adds items to the array list if as long as they are new and unique
	public void add(String id){
		Appointment temp = new Appointment(id);
		boolean check = false;
		for (int i = 0; i < appointment.size(); i++){
			if ( appointment.get(i).getID().equals(id)){
				check = true;
				}
			}
		if ( check == true){
			throw new IllegalArgumentException("ID Already Exist");
			}
		else {
			appointment.add(temp);
			System.out.println("Id and appointment have been added.");
			}
		}
	
	// Takes in a string id and removes the contact ID from the Task_Service array list
	 public void delete(String id){
		 for ( int i = 0; i < appointment.size(); i++){
			 if (appointment.get(i).getID().equals(id)){
				 appointment.remove(i);
				 System.out.println("Id and appointment have been removed.");
				 }
			 }
		 }
	 
	 // getter for the array list
	 public ArrayList<Appointment> getAppointmentService(){
		 return this.appointment;
		 }
	 }