//Richard Howell
//SNHU
//CS-320
// 2/6/2023

package AppointmentService;

import java.util.Date;


public class Appointment {
	// private variables for appointments, date, and description
	private String appointmentID;
	private Date date = new Date();
	private Date currentDate = new Date();
	private StringBuffer description = new StringBuffer(50);
	
	
	// constructor that takes an id, date , and description and makes sure the length is correct, not null, and is not in the past
	public Appointment (String id, Date date, String description) {
		if ( id == null ||id.length() > 10) {
			throw new IllegalArgumentException("Nonvalid ID");
			}
	
		if ( date == null ||date.before(currentDate) ) {
			throw new IllegalArgumentException("Nonvalid Date");
			}
		if ( description == null ||description.length() > 50) {
			throw new IllegalArgumentException("Nonvalid Description");
			}
		this.appointmentID = id;
		this.date = date;
		this.description.append(description);
		}
	
	// constructor that takes in a id
	public Appointment (String id ) {
		if ( id.length() > 10 || id == null) {
			throw new IllegalArgumentException("Id is invalid");
			}
		this.appointmentID = id;
		}
	
	// Setters and getters for the Appointment Class
	public String getID() {
		return this.appointmentID;
		}
	
	public String getDescription() {
		return this.description.toString();
		}
	
	public Date getDate() {
		return this.date;
		}
	
	public void setDescription() {
		this.description.setLength(0);
		this.description.append(description);
		}
		
	
	public void setDate( int date, int month, int year) {
		this.date.setDate(date);
		this.date.setMonth(month);
		this.date.setYear(year);
		}
	}

	
